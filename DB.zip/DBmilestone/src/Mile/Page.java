package Mile;

import java.io.*;
import java.util.*;

public class Page implements Serializable{
private static final long serialVersionUID = 1L;
    
    private final int pageNum; // the page number
    private int maxRows; 
    private int usedrows;
    
    // the maximum number of rows in the page
    private final Vector<Tuple> tuples; // the vector of tuples in the page
    
    public Page(int pageNum) {
        this.pageNum = pageNum;
        this.maxRows = 5;
        this.tuples = new Vector<>();
    }
    
    public int getPageNum() {
        return pageNum;
    }
    
    public boolean isFull() {
        return usedrows == maxRows-1;
    }
    
    public Vector<Tuple> getTuples(){
    	return this.tuples;
    }
    
   public boolean isEmpty() {
        return usedrows==0;
    }
    
    
    public void addTuple(Tuple tuple) throws IOException {
        if (isFull()) {
            throw new IOException("Page is full.");
        }
        tuples.add(tuple);
    }
    
    
    
    public void savePage() throws IOException {
        String fileName = "page" + pageNum + ".class";
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(this);
        }
    }
    
    public static Page loadPage(int pageNum) throws IOException, ClassNotFoundException {
        String fileName = "page" + pageNum + ".class";
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            return (Page) ois.readObject();
        }
    }
}


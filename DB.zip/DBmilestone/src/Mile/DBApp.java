package Mile;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.util.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class DBApp {
	
	
	public DBApp() {
		
	}
	
	
	
	public void createTable(String strTableName, 
			 String strClusteringKeyColumn, 
			Hashtable<String,String> htblColNameType, 
			Hashtable<String,String> htblColNameMin, 
			Hashtable<String,String> htblColNameMax ) throws IOException 
			 {
		
		Table newtable = new Table(strTableName);
		newtable.saveTable();
		Set<String> setOfKeys = htblColNameType.keySet();
		Iterator<String> itr = setOfKeys.iterator();
		try(BufferedWriter writer = new BufferedWriter(new FileWriter("metadata.csv",false))){
		while(itr.hasNext())
			{
			
			String name = strTableName;
			String colname = itr.next();
			boolean clusteringkey = colname.equals(strClusteringKeyColumn);
			String colType = htblColNameType.get(colname);
			String  colMin = htblColNameMin.get(colname);
			String colMax = htblColNameMax.get(colname);
			
			String row = name + "," + colname + "," + colType + "," + clusteringkey + "," + null + "," + null + "," + colMin + "," + colMax;
			writer.write(row);
			writer.newLine();
			
			
			}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
	public void insertIntoTable(String strTableName, 
			 Hashtable<String,Object> htblColNameValue) throws ClassNotFoundException, IOException, ParseException {
			Table table= Table.loadTable(strTableName);
			Vector<Object> temp = new Vector<>();
			for (String key : htblColNameValue.keySet()) {
				String csvFile = "metadata.csv";
		        String line = "";
		        String curr;
		        String csvSplitBy = ",";

		        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
		            while ((line = br.readLine()) != null) {
		                // use comma as separator
		                String[] data = line.split(csvSplitBy);
		                // process the data as needed
		                if(columnfound(data,key)) {
		                	if(htblColNameValue.get(key) instanceof String) {
		                	    curr = (String) htblColNameValue.get(key);
		                	    int result1 = curr.compareTo(data[6]);
		                	    int result2 = curr.compareTo(data[7]);
		                	    if(result1>=0 && result2<=0)
		                	    	temp.add(htblColNameValue.get(key));
		                	}
		                	if(htblColNameValue.get(key) instanceof Integer) {
		                		Integer curr2 = (Integer) htblColNameValue.get(key);
		                		if(curr2>=Integer.parseInt(data[6]) && curr2<Integer.parseInt(data[7]))
		                			temp.add(htblColNameValue.get(key));
		                				
		                	}
		                    if(htblColNameValue.get(key) instanceof Double) {
		                    	Double curr3 = (Double) htblColNameValue.get(key);
		                    	if(curr3>=Double.parseDouble(data[6])&& curr3<Double.parseDouble(data[7]));
		                    		temp.add(htblColNameValue.get(key));
		                    }
		                    if(htblColNameValue.get(key) instanceof Date) {
		                    	Date curr4 = (Date) htblColNameValue.get(key);
		                    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		                    	Date date1 = dateFormat.parse(data[6]);
		                    	Date date2 = dateFormat.parse(data[7]);
		                    	int result1 = curr4.compareTo(date1);
		                	    int result2 = curr4.compareTo(date2);
		                	    if(result1>=0 && result2<=0)
		                	    	temp.add(htblColNameValue.get(key));
		                    }
		                }
		                
		            }
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		        
			}
			Tuple newtuple = new Tuple(temp);
			
	} 
	public static boolean columnfound(String[] arr, String target) {
	    for (int i = 0; i < arr.length; i++) {
	        if (arr[i].equals(target)) {
	            return true;
	        }
	    }
	    return false;
	}

	
	
	public static void main (String [] args) throws ClassNotFoundException, IOException {
		DBApp dbapp = new DBApp();
		Hashtable<String,String> htblColNameType=new Hashtable<String,String>();
		Hashtable<String,String> htblColNameMin=new Hashtable<String,String>();
		Hashtable<String,String> htblColNameMax=new Hashtable<String,String>();
		Hashtable<String,Object> htblColNameValue=new Hashtable<String,Object>();
		htblColNameType.put("id","java.lang.integer");
		htblColNameType.put("name", "java.lang.String"); 
		htblColNameType.put("gpa", "java.lang.double"); 
		htblColNameMin.put("id", "0");
		htblColNameMin.put("name","A");
		htblColNameMin.put("gpa","0.0");
		htblColNameMax.put("id","10000");
		htblColNameMax.put("name","ZZZZ");
		htblColNameMax.put("gpa","ZZZZ");
		htblColNameValue.put("id",new Integer(123));
		htblColNameValue.put("name",new String("yassin"));
		htblColNameValue.put("gpa",new Double(0.86));
		
		try {
			dbapp.createTable("Students","id",htblColNameType,htblColNameMin,htblColNameMax);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();}
		
		
		
		
	}
	
}



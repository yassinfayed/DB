package Mile;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;

public class Table implements Serializable {
	private static final long serialVersionUID = 1L;
    private String name;

    private Vector<Page> pages;

    public Table(String name) {
        this.name = name;
        this.pages = new Vector<>();
    }

    public String getName() {
        return name;
    }

    
    public Vector<Page> getPages() {
        return pages;
    }


    public void addPage(Page page) {
        pages.add(page);
    }
    
    public void saveTable() throws IOException {
        String fileName = "table_" + name + ".class";
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(this);
        }
    }

    public static Table loadTable(String tableName) throws IOException, ClassNotFoundException {
        String fileName = "table_" + tableName + ".class";
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            return (Table) ois.readObject();
        }
    }
}

package Mile;
import java.io.Serializable;
import java.util.*;

public class Tuple implements Serializable{
	
	    private Vector<Object> values;

	    public Tuple(Vector<Object> values) {
	        this.values = values;
	    }
	    
	    
	}

